#![no_std]

use gstd::{collections::BTreeMap, ActorId, exec, msg, prelude::*};
use codec::{Decode, Encode};
use tiny_keccak::{Hasher, Keccak};
// use secp256k1::{Message, PublicKey, Secp256k1, Signature};

#[derive(Default, Debug)]
struct GearDIDRegistry {
    owners: BTreeMap<ActorId, ActorId>,
    delegates: BTreeMap<ActorId, BTreeMap<[u8; 32], BTreeMap<ActorId, u64>>>,
    changed: BTreeMap<ActorId, u64>,
    nonce: BTreeMap<ActorId, u64>,
}

#[derive(Encode)]
struct DIDOwnerChanged {
    identity: ActorId,
    owner: ActorId,
    previous_change: u64,
}

#[derive(Encode)]
struct DIDDelegateChanged {
    identity: ActorId,
    delegate_type: [u8; 32],
    delegate: ActorId,
    valid_to: u64,
    previous_change: u64,
}

#[derive(Encode)]
struct DIDAttributeChanged {
    identity: ActorId,
    name: [u8; 32],
    value: Vec<u8>,
    valid_to: u64,
    previous_change: u64,
}

impl GearDIDRegistry {
    fn identity_owner(&self, identity: &ActorId) -> ActorId {
        *self.owners.get(identity).unwrap_or(identity)
    }

    fn check_signature(&mut self, identity: &ActorId, sig: (u8, [u8; 32], [u8; 32]), hash: [u8; 32]) -> ActorId {
        let (v, r, s) = sig;
        let signer = ecrecover(hash, v, r, s);
        assert_eq!(signer, self.identity_owner(identity), "bad_signature");
        *self.nonce.entry(signer).or_default() += 1;
        signer
    }

    fn valid_delegate(&self, identity: &ActorId, delegate_type: [u8; 32], delegate: &ActorId) -> bool {
        if let Some(validity) = self.delegates.get(identity).and_then(|d| d.get(&delegate_type).and_then(|d| d.get(delegate))) {
            return *validity > exec::block_timestamp();
        }
        false
    }

    fn change_owner(&mut self, identity: &ActorId, actor: &ActorId, new_owner: ActorId) {
        assert_eq!(*actor, self.identity_owner(identity), "bad_actor");
        self.owners.insert(*identity, new_owner);
        let previous_change = self.changed.insert(*identity, exec::block_timestamp()).unwrap_or(0);
        let event = DIDOwnerChanged {
            identity: *identity,
            owner: new_owner,
            previous_change,
        };
        msg::reply(event, 0).unwrap();
    }

    fn add_delegate(&mut self, identity: &ActorId, actor: &ActorId, delegate_type: [u8; 32], delegate: ActorId, validity: u64) {
        assert_eq!(*actor, self.identity_owner(identity), "bad_actor");
        let valid_to = exec::block_timestamp() + validity;
        self.delegates.entry(*identity).or_default().entry(delegate_type).or_default().insert(delegate, valid_to);
        let previous_change = self.changed.insert(*identity, exec::block_timestamp()).unwrap_or(0);
        let event = DIDDelegateChanged {
            identity: *identity,
            delegate_type,
            delegate,
            valid_to,
            previous_change,
        };
        msg::reply(event, 0).unwrap();
    }

    fn set_attribute(&mut self, identity: &ActorId, actor: &ActorId, name: [u8; 32], value: Vec<u8>, validity: u64) {
        assert_eq!(*actor, self.identity_owner(identity), "bad_actor");
        let valid_to = exec::block_timestamp() + validity;
        let previous_change = self.changed.insert(*identity, exec::block_timestamp()).unwrap_or(0);
        let event = DIDAttributeChanged {
            identity: *identity,
            name,
            value,
            valid_to,
            previous_change,
        };
        msg::reply(event, 0).unwrap();
    }

    fn revoke_attribute(&mut self, identity: &ActorId, actor: &ActorId, name: [u8; 32], value: Vec<u8>) {
        assert_eq!(*actor, self.identity_owner(identity), "bad_actor");
        let previous_change = self.changed.insert(*identity, exec::block_timestamp()).unwrap_or(0);
        let event = DIDAttributeChanged {
            identity: *identity,
            name,
            value,
            valid_to: 0,
            previous_change,
        };
        msg::reply(event, 0).unwrap();
    }
}

fn ecrecover(hash: [u8; 32], v: u8, r: [u8; 32], s: [u8; 32]) -> ActorId {
    // Investigar
    unimplemented!();
}

#[derive(Encode, Decode)]
enum Action {
    ChangeOwner { identity: ActorId, new_owner: ActorId },
    ChangeOwnerSigned { identity: ActorId, sig: (u8, [u8; 32], [u8; 32]), new_owner: ActorId },
    AddDelegate { identity: ActorId, delegate_type: [u8; 32], delegate: ActorId, validity: u64 },
    AddDelegateSigned { identity: ActorId, sig: (u8, [u8; 32], [u8; 32]), delegate_type: [u8; 32], delegate: ActorId, validity: u64 },
    SetAttribute { identity: ActorId, name: [u8; 32], value: Vec<u8>, validity: u64 },
    SetAttributeSigned { identity: ActorId, sig: (u8, [u8; 32], [u8; 32]), name: [u8; 32], value: Vec<u8>, validity: u64 },
    RevokeAttribute { identity: ActorId, name: [u8; 32], value: Vec<u8> },
    RevokeAttributeSigned { identity: ActorId, sig: (u8, [u8; 32], [u8; 32]), name: [u8; 32], value: Vec<u8> },
}

#[gstd::async_main]
async fn main() {
    let mut registry: GearDIDRegistry = GearDIDRegistry::default();
    let action: Action = msg::load().expect("Unable to decode input message");

    match action {
        Action::ChangeOwner { identity, new_owner } => {
            let actor = msg::source();
            registry.change_owner(&identity, &actor, new_owner);
        }
        Action::ChangeOwnerSigned { identity, sig, new_owner } => {
            let actor = msg::source();
            let hash = hash_message("changeOwner", &[identity.encode(), new_owner.encode()]);
            let signer = registry.check_signature(&identity, sig, hash);
            registry.change_owner(&identity, &signer, new_owner);
        }
        Action::AddDelegate { identity, delegate_type, delegate, validity } => {
            let actor = msg::source();
            registry.add_delegate(&identity, &actor, delegate_type, delegate, validity);
        }
        Action::AddDelegateSigned { identity, sig, delegate_type, delegate, validity } => {
            let actor = msg::source();
            let hash = hash_message("addDelegate", &[identity.encode(), delegate_type.encode(), delegate.encode(), validity.encode()]);
            let signer = registry.check_signature(&identity, sig, hash);
            registry.add_delegate(&identity, &signer, delegate_type, delegate, validity);
        }
        Action::SetAttribute { identity, name, value, validity } => {
            let actor = msg::source();
            registry.set_attribute(&identity, &actor, name, value, validity);
        }
        Action::SetAttributeSigned { identity, sig, name, value, validity } => {
            let actor = msg::source();
            let hash = hash_message("setAttribute", &[identity.encode(), name.encode(), value.encode(), validity.encode()]);
            let signer = registry.check_signature(&identity, sig, hash);
            registry.set_attribute(&identity, &signer, name, value, validity);
        }
        Action::RevokeAttribute { identity, name, value } => {
            let actor = msg::source();
            registry.revoke_attribute(&identity, &actor, name, value);
        }
        Action::RevokeAttributeSigned { identity, sig, name, value } => {
            let actor = msg::source();
            let hash = hash_message("revokeAttribute", &[identity.encode(), name.encode(), value.encode()]);
            let signer = registry.check_signature(&identity, sig, hash);
            registry.revoke_attribute(&identity, &signer, name, value);
        }
    }
}

fn hash_message(method: &str, args: &[Vec<u8>]) -> [u8; 32] {
    let mut input = Vec::new();
    input.push(0x19);
    input.push(0);
    input.extend_from_slice(&gstd::msg::source().encode());
    for arg in args {
        input.extend_from_slice(arg);
    }
    input.extend_from_slice(method.as_bytes());

    let mut hasher = Keccak::v256();
    hasher.update(&input);
    let mut output = [0u8; 32];
    hasher.finalize(&mut output);
    output
}